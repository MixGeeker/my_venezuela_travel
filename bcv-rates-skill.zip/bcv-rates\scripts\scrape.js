/**
 * BCV 官方汇率爬虫
 * 访问 bcv.org.ve 首页，提取 Tipo de Cambio de Referencia 数据并截图
 *
 * 用法:
 *   node scrape.js                    # 爬取所有汇率 + 截图
 *   node scrape.js --json             # 仅输出 JSON（不截图）
 *   node scrape.js --currency USD     # 仅查询指定币种
 */

const fs = require('fs');
const path = require('path');
const { chromium } = require('playwright');

const BCV_URL = 'https://www.bcv.org.ve/';

// 已知币种及其在页面中的 DOM ID
const CURRENCY_MAP = {
  EUR: 'euro',   // #euro
  CNY: 'yuan',   // #yuan
  TRY: 'lira',   // #lira
  RUB: 'rublo',  // #rublo
  USD: 'dolar',  // #dolar
};

const CURRENCIES = Object.keys(CURRENCY_MAP);

// 关键选择器
const SELECTORS = {
  // 汇率板块容器 section
  rateSection: 'section#block-views-47bbee0af9473fcf0d6df64198f4df6b',
  rateSectionAlt: '.view-tipo-de-cambio-oficial-del-bcv',
  // 各币种汇率值: #<id> strong
  rateValue: (domId) => `#${domId} strong`,
  // 日期
  fechaValor: '.pull-right.dinpro .date-display-single',
  fechaValorAlt: '.pull-right.dinpro',
};

/**
 * 解析命令行参数
 */
function parseArgs() {
  const args = process.argv.slice(2);
  let jsonOnly = false;
  let filterCurrency = null;

  for (let i = 0; i < args.length; i++) {
    switch (args[i]) {
      case '--json':
        jsonOnly = true;
        break;
      case '--currency':
        filterCurrency = args[++i]?.toUpperCase();
        if (!CURRENCIES.includes(filterCurrency)) {
          console.error(`未知币种: ${filterCurrency}`);
          console.log(`支持的币种: ${CURRENCIES.join(', ')}`);
          process.exit(1);
        }
        break;
      default:
        console.error(`未知参数: ${args[i]}`);
        console.log('用法:');
        console.log('  node scrape.js              # 爬取所有汇率 + 截图');
        console.log('  node scrape.js --json       # 仅输出 JSON');
        console.log('  node scrape.js --currency USD  # 仅查询指定币种');
        process.exit(1);
    }
  }

  return { jsonOnly, filterCurrency };
}

/**
 * 启动浏览器并访问 BCV 页面
 * 注意: 必须使用 headless: false，BCV 网站会阻止 headless 浏览器
 */
async function launchAndNavigate() {
  const browser = await chromium.launch({
    channel: 'chrome',
    headless: false,
  });

  const context = await browser.newContext({
    viewport: { width: 1920, height: 1080 },
    locale: 'es-VE',
  });

  const page = await context.newPage();

  console.log('正在访问 BCV 网站...');
  await page.goto(BCV_URL, {
    waitUntil: 'domcontentloaded',
    timeout: 60000,
  });

  // 等待汇率区域加载
  try {
    await page.waitForSelector('#dolar strong', { timeout: 15000 });
    console.log('汇率区域已加载');
  } catch {
    // 回退等待
    console.log('等待页面完全渲染...');
    await page.waitForTimeout(5000);
  }

  return { browser, page };
}

/**
 * 从页面提取汇率数据
 */
async function extractRates(page) {
  console.log('正在提取汇率数据...');

  const rates = {};

  for (const [currency, domId] of Object.entries(CURRENCY_MAP)) {
    const selector = SELECTORS.rateValue(domId);
    try {
      const el = await page.$(selector);
      if (el) {
        const text = await el.textContent();
        rates[currency] = text.trim();
      } else {
        console.warn(`  ⚠️ 未找到 ${currency} (${selector})`);
      }
    } catch (e) {
      console.warn(`  ⚠️ 提取 ${currency} 失败: ${e.message}`);
    }
  }

  // 提取 Fecha Valor
  let fechaValor = '';
  try {
    const fechaEl = await page.$(SELECTORS.fechaValor);
    if (fechaEl) {
      fechaValor = (await fechaEl.textContent()).trim();
    } else {
      // 回退: 从 .pull-right.dinpro 提取
      const altEl = await page.$(SELECTORS.fechaValorAlt);
      if (altEl) {
        const text = (await altEl.textContent()).trim();
        const match = text.match(/Fecha\s*Valor:\s*(.+)/i);
        if (match) fechaValor = match[1].trim();
      }
    }
  } catch (e) {
    console.warn(`  ⚠️ 提取日期失败: ${e.message}`);
  }

  return { rates, fechaValor };
}

/**
 * 截取汇率区域截图
 */
async function takeScreenshot(page) {
  const timestamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
  const filename = `bcv-rates-${timestamp}.png`;
  const screenshotDir = path.join(__dirname, 'screenshots');
  await fs.promises.mkdir(screenshotDir, { recursive: true });
  const screenshotPath = path.join(screenshotDir, filename);

  // 尝试定位汇率区域
  const selectors = [
    SELECTORS.rateSection,
    SELECTORS.rateSectionAlt,
  ];

  let element = null;
  for (const sel of selectors) {
    try {
      element = await page.$(sel);
      if (element) break;
    } catch {
      // 继续尝试
    }
  }

  if (element) {
    await element.screenshot({ path: screenshotPath });
    console.log(`截图已保存: ${screenshotPath}`);
  } else {
    // 回退：截取整页
    await page.screenshot({ path: screenshotPath, fullPage: false });
    console.log(`（未定位汇率区域，截取整页）: ${screenshotPath}`);
  }

  return filename;
}

/**
 * 解析汇率字符串为数值
 * 委内瑞拉格式: 393,22160000 → 393.22160000
 */
function parseRate(rateStr) {
  if (!rateStr) return null;
  // 去掉千分位的点，把逗号替换为小数点
  const cleaned = rateStr.replace(/\./g, '').replace(',', '.');
  const num = parseFloat(cleaned);
  return isNaN(num) ? null : num;
}

/**
 * 主函数
 */
async function main() {
  const { jsonOnly, filterCurrency } = parseArgs();

  let browser;
  try {
    const launched = await launchAndNavigate();
    browser = launched.browser;
    const page = launched.page;

    // 提取汇率
    const data = await extractRates(page);

    if (Object.keys(data.rates).length === 0) {
      console.error('错误: 未能提取到任何汇率数据');
      process.exit(1);
    }

    // 截图
    let screenshotFile = null;
    if (!jsonOnly) {
      screenshotFile = await takeScreenshot(page);
    }

    // 构建结果
    const rates = {};
    for (const [currency, rateStr] of Object.entries(data.rates)) {
      if (filterCurrency && currency !== filterCurrency) continue;
      rates[currency] = {
        raw: rateStr,
        value: parseRate(rateStr),
      };
    }

    const result = {
      timestamp: new Date().toISOString(),
      source: BCV_URL,
      fechaValor: data.fechaValor,
      rates,
      screenshot: screenshotFile,
    };

    // 保存 JSON
    const resultDir = path.join(__dirname, 'results');
    await fs.promises.mkdir(resultDir, { recursive: true });
    const resultPath = path.join(resultDir, 'latest.json');
    await fs.promises.writeFile(resultPath, JSON.stringify(result, null, 2));

    // 控制台输出
    console.log('\n========================================');
    console.log('  BCV 官方汇率 (Tipo de Cambio de Referencia)');
    console.log('========================================\n');

    for (const [currency, info] of Object.entries(rates)) {
      const val = info.value ? info.value.toFixed(8) : info.raw;
      console.log(`  ${currency}  →  ${val} Bs.`);
    }

    console.log(`\n  Fecha Valor: ${data.fechaValor}`);
    console.log(`\n结果已保存: ${resultPath}`);
    if (screenshotFile) {
      console.log(`截图已保存: screenshots/${screenshotFile}`);
    }

    return result;
  } catch (error) {
    console.error(`致命错误: ${error.message}`);
    process.exit(1);
  } finally {
    if (browser) {
      await browser.close();
    }
  }
}

// 主入口
if (require.main === module) {
  main().catch(err => {
    console.error('致命错误:', err);
    process.exit(1);
  });
}

module.exports = { main };
