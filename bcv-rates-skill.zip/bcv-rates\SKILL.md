---
name: bcv-rates
description: 爬取委内瑞拉中央银行 (BCV) 官方汇率。通过 Playwright 访问 bcv.org.ve 主页，提取 EUR/CNY/TRY/RUB/USD 对玻利瓦尔的官方参考汇率，截图汇率区域，并保存 JSON 结果。当用户提到 BCV、汇率、tipo de cambio、tasa、dólar oficial、cambio oficial 时使用。
---

# BCV Rates（委内瑞拉央行官方汇率爬虫）

基于 Node.js + Playwright 的 BCV 官方汇率爬取工具，从 [bcv.org.ve](https://www.bcv.org.ve/) 首页提取 Tipo de Cambio de Referencia 数据。

## 首次部署

在 `scripts/` 目录下执行：

```bash
cd scripts
npm install
```

前置条件：
- Node.js 18+
- 系统已安装 Google Chrome（脚本使用 `channel: 'chrome'`）

## 核心命令

所有命令在 `scripts/` 目录下执行。

### 爬取汇率（scrape.js）

```bash
node scrape.js              # 爬取所有汇率并截图
node scrape.js --json       # 仅输出 JSON（不截图）
node scrape.js --currency USD  # 仅查询指定币种
```

输出：
- JSON 结果: `results/latest.json`
- 汇率截图: `screenshots/bcv-rates-<timestamp>.png`

### 输出格式

```json
{
  "timestamp": "2026-02-13T02:30:00.000Z",
  "source": "https://www.bcv.org.ve/",
  "fechaValor": "Viernes, 13 Febrero 2026",
  "rates": {
    "EUR": 467.33207495,
    "CNY": 56.98450836,
    "TRY": 9.00993742,
    "RUB": 5.09281838,
    "USD": 393.22160000
  },
  "screenshot": "screenshots/bcv-rates-2026-02-13T02-30-00.png"
}
```

## 关键说明

1. **无需登录** — BCV 官方汇率是公开数据，无需认证
2. **汇率含义** — 数值表示 1 单位外币 = X 玻利瓦尔 (Bs.)
3. **更新频率** — BCV 每个工作日更新汇率
4. **Fecha Valor** — 汇率生效日期（可能与当前日期不同）

## Troubleshooting

| 问题 | 解决方法 |
|------|---------|
| 页面加载超时 | 检查网络连接，BCV 网站有时较慢，可尝试重试 |
| 汇率区域为空 | BCV 可能正在更新数据，稍后重试 |
| 选择器找不到 | BCV 改版了页面，需更新 scrape.js 中的选择器 |

## 文件结构

```
scripts/
├── scrape.js           # 爬虫入口
├── package.json        # 依赖 (playwright)
├── results/
│   └── latest.json     # 最新爬取结果
└── screenshots/
    └── bcv-rates-*.png # 汇率截图
```
