const fs = require('fs');
const path = require('path');
const { launchBrowser } = require('./lib/browser');

const config = JSON.parse(fs.readFileSync(path.join(__dirname, 'config.json'), 'utf8'));

// 底层工具（调试脚本需要直接访问，输出更多细节）
const { findInFrames, findInFramesOnce, getAllFrameText } = require('./lib/frame-utils');
const { detectPageState, PageState } = require('./lib/detect');

// 步骤模块
const { logout } = require('./steps/logout');

async function debugLogin(accountId) {
  const account = config.accounts.find(a => a.id === accountId);
  if (!account) {
    console.error(`未知账户: ${accountId}`);
    process.exit(1);
  }

  const password = process.env[account.passwordEnv];
  if (!password) {
    console.error(`未设置密码: ${account.passwordEnv}`);
    process.exit(1);
  }

  console.log(`\n========================================`);
  console.log(`调试登录: ${account.name}`);
  console.log(`========================================\n`);

  const { page, close: closeBrowser } = await launchBrowser({
    slowMo: 300,
    width: 1400,
    height: 900,
  });

  try {
    // 步骤 1：打开登录页（手动实现，打印更多信息）
    console.log('1. 打开登录页...');
    await page.goto(config.urls.login, { waitUntil: 'networkidle', timeout: 60000 });
    await page.waitForTimeout(2000);
    console.log('   ✅ 页面加载完成\n');

    // 分析 frames
    const frames = page.frames();
    console.log(`2. 找到 ${frames.length} 个 frame(s)`);
    frames.forEach((f, i) => console.log(`   Frame ${i}: ${f.url() || '(主frame)'}`));
    console.log('');

    // 步骤 2：查找并填写用户名（带详细输出）
    console.log('3. 查找用户名输入框...');
    const selectors = config.selectors;
    const usernameResult = await findInFrames(page, [
      selectors.usernameInput,
      selectors.usernameInputAlt,
    ], { timeout: 10000 });

    if (!usernameResult) {
      console.log('   ❌ 未找到用户名输入框，请手动检查');
      console.log('   尝试的选择器:');
      console.log(`     - ${selectors.usernameInput}`);
      console.log(`     - ${selectors.usernameInputAlt}`);
      await new Promise(() => {});
    }

    await usernameResult.element.fill(account.id);
    console.log(`   ✅ 已填入: ${account.id}\n`);

    // 点击 Aceptar
    console.log('4. 点击 Aceptar...');
    const acceptResult = await findInFrames(page, [
      selectors.usernameSubmit,
      selectors.usernameSubmitAlt,
    ], { timeout: 5000 });

    if (!acceptResult) {
      console.log('   ❌ 未找到 Aceptar 按钮');
      await new Promise(() => {});
    }

    await acceptResult.element.click();
    console.log('   ✅ 已点击\n');

    // 步骤 3：等待并检测页面状态
    console.log('5. 等待页面响应...');
    await page.waitForTimeout(3000);

    // 输出当前 frames 信息
    const newFrames = page.frames();
    console.log(`   当前 ${newFrames.length} 个 frame(s)`);
    newFrames.forEach((f, i) => console.log(`   Frame ${i}: ${f.url() || '(主frame)'}`));

    // 使用 detectPageState 检测
    console.log('\n   检测页面状态...');
    const passwordResult = await findInFrames(page, [
      selectors.passwordInput,
      selectors.passwordInputAlt,
    ], { timeout: 12000 });

    if (!passwordResult) {
      console.log('   ❌ 未找到密码输入框');
      const state = await detectPageState(page, config);
      console.log(`   页面状态: ${state.state}${state.detail ? ' - ' + state.detail : ''}`);

      if (state.state === PageState.HOME) {
        console.log('   ✅ 已在主页（信任设备自动登录）');
      } else if (state.state === PageState.SECURITY_QUESTIONS) {
        console.log('   ⚠️ 安全问题验证页面');
      } else {
        console.log('   检查页面文本...');
        const pageText = await getAllFrameText(page);
        console.log(`   文本前 300 字符: ${pageText.slice(0, 300)}`);
      }

      await new Promise(() => {});
    }

    // 填入密码
    console.log('\n6. 填入密码...');
    await passwordResult.element.fill(password);
    console.log('   ✅ 密码已填入\n');

    // 点击登录
    console.log('7. 点击登录...');
    const loginBtnResult = await findInFrames(page, [
      selectors.passwordSubmit,
      selectors.passwordSubmitAlt,
    ], { timeout: 5000 });

    if (!loginBtnResult) {
      console.log('   ❌ 未找到登录按钮');
      await new Promise(() => {});
    }

    await loginBtnResult.element.click();
    console.log('   ✅ 已点击登录\n');

    await page.waitForTimeout(5000);

    // 检查结果
    console.log('8. 检查结果...');
    const finalState = await detectPageState(page, config);
    console.log(`   页面状态: ${finalState.state}${finalState.detail ? ' - ' + finalState.detail : ''}`);

    if (finalState.state === PageState.HOME) {
      console.log('   ✅ 登录成功！');

      // 提取余额
      const pageText = await getAllFrameText(page);
      const vesMatch = pageText.match(/cuenta corriente\s+\d{4}-\d{4}-\d{2}-\d{10}\s+([\d.]+,\d{2})/i);
      const usdMatch = pageText.match(/cuenta verde[\s\S]{0,50}?\$?([\d.]+,\d{2})/i);

      console.log('\n   余额:');
      console.log(`   VES: ${vesMatch ? vesMatch[1] : '未找到'}`);
      console.log(`   USD: ${usdMatch ? usdMatch[1] : '未找到'}`);

      // 登出
      await logout(page, config);

    } else if (finalState.state === PageState.SERVER_ERROR) {
      console.log('   ❌ 服务器错误/冷却中');
    } else {
      console.log('   ⚠️ 未知状态');
      const pageText = await getAllFrameText(page);
      console.log(`   文本前 300 字符: ${pageText.slice(0, 300)}`);
    }

    console.log('\n========================================');
    console.log('调试完成！关闭浏览器退出');
    console.log('========================================\n');

    await new Promise(() => {});

  } catch (error) {
    console.error('\n❌ 错误:', error.message);
    await logout(page, config).catch(() => {});
    await new Promise(() => {});
  }
}

const args = process.argv.slice(2);
if (!args[0]) {
  console.error('用法: node debug.js <账户ID>');
  process.exit(1);
}
debugLogin(args[0]).catch(console.error);
