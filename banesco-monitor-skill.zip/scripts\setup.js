const fs = require('fs');
const path = require('path');
const { launchBrowser } = require('./lib/browser');

const config = JSON.parse(fs.readFileSync(path.join(__dirname, 'config.json'), 'utf8'));

// 步骤模块
const { navigate } = require('./steps/navigate');
const { fillUsername } = require('./steps/username');

// 底层工具（setup 需要直接访问 frame 工具来填用户名）
const { findInFrames } = require('./lib/frame-utils');

async function setupTrustDevice(accountId) {
  const account = config.accounts.find(a => a.id === accountId);
  if (!account) {
    console.error(`未知账户: ${accountId}`);
    console.log(`可用账户: ${config.accounts.map(a => a.id).join(', ')}`);
    process.exit(1);
  }

  const password = process.env[account.passwordEnv];
  if (!password) {
    console.error(`未设置密码环境变量: ${account.passwordEnv}`);
    console.log(`请先设置: export ${account.passwordEnv}=your_password`);
    process.exit(1);
  }

  console.log(`\n========================================`);
  console.log(`配置信任设备: ${account.name}`);
  console.log(`========================================\n`);

  const { page, context, close: closeBrowser } = await launchBrowser({
    slowMo: 50,
    width: 1400,
    height: 900,
  });

  try {
    // 步骤 1：打开登录页
    console.log('正在打开登录页面（请等待）...');
    const nav = await navigate(page, config);
    if (!nav.success) {
      console.error(`❌ ${nav.error}`);
      process.exit(1);
    }

    // 尝试自动填入用户名
    try {
      const userResult = await fillUsername(page, accountId, config);
      if (userResult.success) {
        console.log(`✅ 已填入用户名: ${accountId}\n`);
      } else {
        console.log('⚠️ 自动填入用户名失败，请手动输入\n');
      }
    } catch (e) {
      console.log('⚠️ 自动填入用户名失败，请手动输入\n');
    }

    console.log('👉 请按以下步骤操作：');
    console.log('1. 确认用户名已填入（或手动填入）');
    console.log('2. 点击 "Aceptar"');
    console.log('3. 如果遇到安全问题，手动回答');
    console.log('4. 在密码页勾选 "信任此设备"');
    console.log('5. 输入密码并点击 "Aceptar" 登录');
    console.log('6. 登录成功后，关闭浏览器即可\n');

    console.log('浏览器保持打开，请完成登录...\n');
    console.log('登录成功后直接关闭浏览器窗口即可');

    // 保持运行直到用户关闭浏览器
    await new Promise((resolve) => {
      context.on('close', () => {
        console.log('\n✅ 浏览器已关闭，配置完成');
        resolve();
      });
    });

  } catch (error) {
    console.error('\n❌ 错误:', error.message);
    await closeBrowser();
    process.exit(1);
  }
}

// 主函数
const args = process.argv.slice(2);
const accountId = args[0];

if (!accountId) {
  console.log('用法: node setup.js <账户ID>');
  console.log('');
  console.log('示例:');
  console.log('  node setup.js myaccount');
  console.log('');
  console.log('可用账户:');
  config.accounts.forEach(a => {
    console.log(`  ${a.id} - ${a.name}`);
  });
  process.exit(1);
}

setupTrustDevice(accountId).catch(err => {
  console.error('错误:', err);
  process.exit(1);
});
