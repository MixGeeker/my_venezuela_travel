/**
 * 步骤4：提取余额
 * 从主页提取 VES 和 USD 余额，并截图保存。
 */

const fs = require('fs');
const path = require('path');
const { getAllFrameText } = require('../lib/frame-utils');

/**
 * 提取余额信息
 * @param {import('playwright').Page} page
 * @param {string} accountId - 账户 ID（用于截图命名）
 * @param {object} [options]
 * @param {function} [options.log] - 日志函数
 * @returns {Promise<{ves: string|null, usd: string|null, screenshot: string|null}>}
 */
async function extractBalance(page, accountId, options = {}) {
  const log = options.log || console.log;

  try {
    await page.waitForTimeout(2000);
    const pageText = await getAllFrameText(page);

    // 截图
    const screenshotDir = path.join(__dirname, '..', 'screenshots');
    await fs.promises.mkdir(screenshotDir, { recursive: true });
    const screenshotPath = path.join(screenshotDir, `${accountId}-${Date.now()}.png`);
    await page.screenshot({ path: screenshotPath, fullPage: true });

    // 提取 VES 余额
    let ves = null;
    const vesMatch = pageText.match(
      /cuenta corriente\s+\d{4}-\d{4}-\d{2}-\d{10}\s+([\d.]+,\d{2})/i
    );
    if (vesMatch) {
      ves = vesMatch[1];
    } else {
      const vesLoose = pageText.match(/cuenta corriente[^\n]*?([\d.]+,\d{2})/i);
      if (vesLoose) ves = vesLoose[1];
    }

    // 提取 USD 余额
    let usd = null;
    const usdMatch = pageText.match(/cuenta verde[\s\S]{0,50}?\$?([\d.]+,\d{2})/i);
    if (usdMatch) {
      usd = usdMatch[1];
    } else {
      const usdLoose = pageText.match(/cuenta verde[^\n]*?\$?([\d.]+,\d{2})/i);
      if (usdLoose) usd = usdLoose[1];
    }

    log(`  ✅ VES: ${ves || 'N/A'}`);
    log(`  ✅ USD: ${usd || 'N/A'}`);

    return { ves, usd, screenshot: screenshotPath };
  } catch (error) {
    log(`  ⚠️ 余额提取失败: ${error.message}`);
    return { ves: null, usd: null, screenshot: null };
  }
}

module.exports = { extractBalance };
