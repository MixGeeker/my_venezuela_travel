/**
 * 批量转账编排器
 * 登录 → 逐笔转账 → 登出 → 保存结果
 * Fail-fast: 任何一笔失败立即停止所有后续转账
 *
 * 用法:
 *   node transfer.js --from <accountId> --batch transfers.json
 *   node transfer.js --from <accountId> -t 01340000000000000000:1,00:pago_test
 *   node transfer.js --from <accountId> -t 账号1:金额1:概念1 -t 账号2:金额2:概念2
 */

const fs = require('fs');
const path = require('path');
const { launchBrowser } = require('./lib/browser');

const config = JSON.parse(fs.readFileSync(path.join(__dirname, 'config.json'), 'utf8'));

// 登录步骤
const { navigate } = require('./steps/navigate');
const { fillUsername } = require('./steps/username');
const { fillPassword } = require('./steps/password');
const { logout } = require('./steps/logout');
const { detectPageState, PageState } = require('./lib/detect');

// 转账步骤
const { transfer } = require('./steps/transfer');

// 状态管理
const { checkCooldown, recordLogin, recordLogout } = require('./lib/state');

/**
 * 优先复用已有登录会话，避免不必要的二次安全验证。
 * @param {import('playwright').Page} page
 * @param {object} config
 * @returns {Promise<{reuse: boolean, blockedBySecurity?: boolean}>}
 */
async function probeExistingSession(page, config) {
  await page.goto(config.urls.transferTerceros, {
    waitUntil: 'networkidle',
    timeout: 60000,
  });
  await page.waitForTimeout(2000);

  const state = await detectPageState(page, config);
  if (state.state === PageState.SECURITY_QUESTIONS) {
    return { reuse: false, blockedBySecurity: true };
  }

  const currentUrl = page.url().toLowerCase();
  const hasDirectorio = await page.$('input[value="Directorio"]') ||
                        await page.$('button:has-text("Directorio")');

  if (hasDirectorio) {
    return { reuse: true };
  }

  // 某些情况下入口页还未渲染按钮，但 URL 已在转账路径，仍视为可复用会话。
  if (currentUrl.includes('/transferencias/tercerosbanesco.aspx')) {
    return { reuse: true };
  }

  // 在主页也代表会话可用，后续 transfer() 会自行跳转到转账页。
  if (state.state === PageState.HOME) {
    return { reuse: true };
  }

  return { reuse: false };
}

/**
 * 解析命令行参数
 */
function parseArgs() {
  const args = process.argv.slice(2);
  let loginAccountId = null;
  let batchFile = null;
  const transfers = [];
  const sourceAccount = 'VES'; // 仅支持 VES 账户转账

  for (let i = 0; i < args.length; i++) {
    switch (args[i]) {
      case '--from':
        loginAccountId = args[++i];
        break;
      case '--batch':
        batchFile = args[++i];
        break;
      case '-t':
      case '--transfer': {
        // 格式: 账号:金额:概念
        const parts = args[++i].split(':');
        if (parts.length < 2) {
          console.error(`无效的转账参数: ${args[i]}，格式: 账号:金额:概念`);
          process.exit(1);
        }
        transfers.push({
          account: parts[0],
          amount: parts[1],
          concept: parts.slice(2).join(':') || 'pago',
        });
        break;
      }
      // --source 已移除，仅支持 VES 账户转账
      default:
        console.error(`未知参数: ${args[i]}`);
        process.exit(1);
    }
  }

  // 如果指定了 batch 文件，从文件读取
  if (batchFile) {
    const batchPath = path.resolve(batchFile);
    if (!fs.existsSync(batchPath)) {
      console.error(`批次文件不存在: ${batchPath}`);
      process.exit(1);
    }
    const batchData = JSON.parse(fs.readFileSync(batchPath, 'utf8'));
    // sourceAccount 固定为 VES，忽略配置文件中的值
    if (batchData.transfers) {
      batchData.transfers.forEach(t => {
        transfers.push({
          account: t.account,
          amount: t.amount,
          concept: t.concept || batchData.defaults?.concept || 'pago',
          name: t.name,
        });
      });
    }
  }

  if (!loginAccountId) {
    console.error('未指定登录账户。请使用 --from <accountId> 指定。');
    process.exit(1);
  }

  if (transfers.length === 0) {
    console.error('没有转账任务。使用 -t 或 --batch 指定转账。');
    console.log('');
    console.log('用法:');
    console.log('  node transfer.js --from <accountId> --batch transfers.json');
    console.log('  node transfer.js --from <accountId> -t 账号:金额:概念');
    console.log('  node transfer.js --from <accountId> -t 01340000000000000000:1,00:pago_test');
    console.log('');
    console.log('参数:');
    console.log('  --from <账户ID>     登录账户 (必需)');
    console.log('  --batch <文件>      从 JSON 文件读取转账批次');
    console.log('  -t <账号:金额:概念>  添加单笔转账');
    // 仅支持 VES 账户，无需 --source 参数
    process.exit(1);
  }

  return { loginAccountId, transfers, sourceAccount };
}

/**
 * 执行批量转账
 */
async function runTransfers(loginAccountId, batch, sourceAccount) {
  const account = config.accounts.find(a => a.id === loginAccountId);
  if (!account) {
    console.error(`未知登录账户: ${loginAccountId}`);
    console.log(`可用账户: ${config.accounts.map(a => a.id).join(', ')}`);
    process.exit(1);
  }

  const password = process.env[account.passwordEnv];
  if (!password) {
    console.error(`未设置密码: ${account.passwordEnv}`);
    process.exit(1);
  }

  console.log(`\n========================================`);
  console.log(`批量转账: ${account.name}`);
  console.log(`转账笔数: ${batch.length}`);
  console.log(`扣款类型: ${sourceAccount}`);
  console.log(`========================================\n`);

  // 打印转账清单
  batch.forEach((t, i) => {
    console.log(`  ${i + 1}. ${t.name || t.account} → ${t.amount} (${t.concept})`);
  });
  console.log('');

  // 检查冷却
  const cooldown = checkCooldown(loginAccountId);
  if (cooldown.needWait) {
    console.log(`⏳ ${cooldown.reason}，等待 ${cooldown.remainingSeconds} 秒...`);
    await new Promise(r => setTimeout(r, cooldown.remainingSeconds * 1000));
  }

  const { page, close: closeBrowser } = await launchBrowser();

  const results = [];
  let failedAt = null;

  try {
    // ====== 登录/会话复用 ======
    console.log('步骤 1: 检查现有会话...');
    const probe = await probeExistingSession(page, config);
    if (probe.blockedBySecurity) {
      throw new Error('触发安全验证，无法自动转账');
    }

    if (probe.reuse) {
      console.log('✅ 检测到已登录会话，跳过重新登录\n');
      recordLogin(loginAccountId);
    } else {
      console.log('  未检测到可复用会话，执行标准登录...');
      const nav = await navigate(page, config);
      if (!nav.success) throw new Error(`页面加载失败: ${nav.error}`);

      const user = await fillUsername(page, account.id, config);
      if (!user.success) throw new Error(`用户名步骤失败: ${user.error}`);

      const pwd = await fillPassword(page, password, config);
      if (pwd.securityQuestions) throw new Error('触发安全验证，无法自动转账');
      if (!pwd.success && !pwd.alreadyHome) throw new Error(`登录失败: ${pwd.error}`);
      recordLogin(loginAccountId);
      console.log('✅ 登录成功\n');
    }

    // ====== 逐笔转账 ======
    console.log('步骤 2: 开始转账...\n');

    for (let i = 0; i < batch.length; i++) {
      const t = batch[i];
      const label = t.name || t.account;
      console.log(`--- 转账 ${i + 1}/${batch.length}: ${label} ---`);

      const result = await transfer(page, config, t, sourceAccount);
      results.push({
        account: t.account,
        amount: t.amount,
        concept: t.concept,
        name: t.name || null,
        ...result,
      });

      if (!result.success) {
        console.error(`\n❌ 转账失败: ${result.error}`);
        console.error(`⛔ 停止所有后续转账！\n`);
        failedAt = i;

        // 将剩余转账标记为跳过
        for (let j = i + 1; j < batch.length; j++) {
          results.push({
            account: batch[j].account,
            amount: batch[j].amount,
            concept: batch[j].concept,
            name: batch[j].name || null,
            success: false,
            error: '前序转账失败，已跳过',
          });
        }
        break;
      }

      console.log(`✅ 转账成功: ${label} → ${t.amount}\n`);

      // 转账间隔
      if (i < batch.length - 1) {
        console.log('  等待 3 秒...');
        await page.waitForTimeout(3000);
      }
    }

  } catch (error) {
    console.error(`\n❌ 致命错误: ${error.message}`);
    if (results.length === 0) {
      results.push({
        account: 'N/A',
        amount: 'N/A',
        success: false,
        error: error.message,
      });
    }
  } finally {
    // ====== 始终登出 ======
    console.log('\n步骤 3: 登出...');
    try {
      const logoutResult = await logout(page, config);
      if (logoutResult.success) {
        recordLogout(loginAccountId);
      }
    } catch (e) {
      console.error(`  ⚠️ 登出异常: ${e.message}`);
    }

    await closeBrowser();
  }

  // ====== 保存结果 ======
  const successCount = results.filter(r => r.success).length;
  const output = {
    timestamp: new Date().toISOString(),
    loginAccount: loginAccountId,
    sourceAccount,
    totalCount: batch.length,
    successCount,
    failedAt,
    results,
  };

  const resultDir = path.join(__dirname, 'results');
  await fs.promises.mkdir(resultDir, { recursive: true });
  const resultPath = path.join(resultDir, 'transfer-latest.json');
  await fs.promises.writeFile(resultPath, JSON.stringify(output, null, 2));

  // 打印汇总
  console.log('\n========================================');
  console.log(`转账完成: ${successCount}/${batch.length} 笔成功`);
  console.log('========================================');
  results.forEach((r, i) => {
    if (r.success) {
      console.log(`  ✅ ${r.name || r.account} → ${r.amount} (回执: ${r.receiptNumber || 'N/A'})`);
    } else {
      console.log(`  ❌ ${r.name || r.account} → ${r.error}`);
    }
  });
  console.log(`\n结果已保存: ${resultPath}`);

  return output;
}

// 主入口
if (require.main === module) {
  const { loginAccountId, transfers, sourceAccount } = parseArgs();
  runTransfers(loginAccountId, transfers, sourceAccount).catch(err => {
    console.error('致命错误:', err);
    process.exit(1);
  });
}

module.exports = { runTransfers };
