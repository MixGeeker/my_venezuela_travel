---
name: banesco-monitor
description: 通过 banesco-monitor CLI 脚本操作 Banesco Online 银行（Playwright + 持久化浏览器）。支持：查询余额(check.js)、转账到 Banesco 第三方(transfer.js)、配置信任设备(setup.js)、交互式登录(interactive.js)。当用户提到 Banesco、余额、转账、查账、saldo、transferencia、consulta 时使用。
---

# Banesco Monitor (CLI)

基于 Node.js + Playwright 的 Banesco Online 自动化工具，使用持久化浏览器 profile 保持信任设备状态。

## 首次部署

在 `scripts/` 目录下执行：

```bash
cd scripts
npm install
```

前置条件：
- Node.js 18+
- 系统已安装 Google Chrome（脚本使用 `channel: 'chrome'`）

然后编辑 `scripts/config.json`，填入账户信息：

```json
{
  "accounts": [
    {
      "id": "your-account-id",
      "name": "描述 - YOUR NAME",
      "type": "personal",
      "passwordEnv": "BANESCO_YOURNAME_PASS"
    }
  ]
}
```

设置密码环境变量：

```powershell
# PowerShell
$env:BANESCO_YOURNAME_PASS = "your_password"
```

```bash
# Bash
export BANESCO_YOURNAME_PASS="your_password"
```

最后运行信任设备配置（首次必须）：

```bash
node setup.js <accountId>
```

在浏览器中手动完成安全问题 → 勾选"信任此设备" → 登录成功后关闭浏览器。

## URL 官方（Anti-Phishing）

- Login: `https://www.banesconline.com/mantis/Website/Login.aspx`

## 核心命令

所有命令在 `scripts/` 目录下执行。

### 1) 配置信任设备（setup.js）

首次使用或银行要求重新验证时执行：

```bash
node setup.js <accountId>
```

- 脚本自动填用户名，人工完成安全问题和勾选信任设备
- 登录成功后关闭浏览器即完成

### 2) 查询余额（check.js）

```bash
node check.js                    # 查所有账户
node check.js accountA           # 查单个
node check.js accountA accountB  # 查多个
```

输出：
- JSON: `results/latest.json`
- 失败截图: `screenshots/*-error-*.png`

### 3) 转账 — Terceros en Banesco（transfer.js）

单笔：

```bash
node transfer.js --from <accountId> -t <收款账号>:<金额>:<概念>
```

批量（从 JSON 文件）：

```bash
node transfer.js --from <accountId> --batch transfers.json
```

多笔：

```bash
node transfer.js --from <accountId> -t <acct1>:<amt1>:<concept1> -t <acct2>:<amt2>:<concept2>
```

输出：
- 结果 JSON: `results/transfer-latest.json`
- 回执截图: `screenshots/transfer-*.png`

转账详细格式和批量 JSON 结构见 [references/transfer-guide.md](references/transfer-guide.md)。

### 4) 辅助工具

- `node interactive.js <accountId>` — 交互式登录，手动处理安全验证
- `node debug.js <accountId>` — 调试 frame/选择器问题

## 关键操作规则

1. **禁止并行运行** — Banesco 不支持同账户多会话，不要同时跑 check.js 和 transfer.js
2. **仅支持 Directorio 内联系人** — transfer.js 只能转给已保存在银行通讯录的收款人
3. **金额格式** — 逗号做小数点：`1,00`、`1500,00`、`10.500,00`
4. **概念/备注** — 最少 3 个字符，建议纯文本
5. **冷却时间** — 正常登出后等 1 分钟，异常退出等 5 分钟（自动处理）

## Troubleshooting

| 问题 | 解决方法 |
|------|---------|
| 触发安全验证/preguntas de seguridad | `node setup.js <accountId>` 重新配置信任设备 |
| `Target page, context or browser has been closed` | 浏览器 profile 损坏，脚本会自动备份并重建，之后需重新 `setup.js` |
| 银行页面加载慢/超时 | 登录等待默认 30s，可调节 password.js 的 `homeWaitTimeout` |
| 找不到选择器/页面改版 | 用 `node debug.js <accountId>` 排查，更新 `config.json` 的 selectors |
| 密码环境变量未设置 | 检查 `$env:BANESCO_XXX_PASS`（PowerShell）或 `echo $BANESCO_XXX_PASS`（Bash） |

## 文件结构

```
scripts/
├── check.js              # 余额查询入口
├── setup.js              # 信任设备配置
├── transfer.js           # 转账入口
├── interactive.js        # 交互式登录
├── debug.js              # 调试工具
├── config.json           # 账户/选择器/URL 配置
├── transfers.example.json # 批量转账示例
├── package.json          # 依赖 (playwright)
├── lib/
│   ├── browser.js        # 浏览器启动/持久化上下文
│   ├── detect.js         # 页面状态检测（登录/主页/安全问题/错误）
│   ├── frame-utils.js    # iframe 内元素查找工具
│   └── state.js          # 登录状态/冷却时间管理
└── steps/
    ├── navigate.js       # 步骤1: 打开登录页
    ├── username.js       # 步骤2: 填用户名 + Aceptar
    ├── password.js       # 步骤3: 填密码 + 登录
    ├── balance.js        # 步骤4: 提取 VES/USD 余额
    ├── transfer.js       # 转账流程（目录搜索→填表→确认→回执）
    └── logout.js         # 步骤5: 登出
```

## 参考文档

- [config.json 配置详解](references/config-reference.md) — 账户配置、CSS 选择器、URL
- [转账完整指南](references/transfer-guide.md) — 格式、批量 JSON、回执、错误处理
