const fs = require('fs');
const path = require('path');
const { launchBrowser } = require('./lib/browser');

const config = JSON.parse(fs.readFileSync(path.join(__dirname, 'config.json'), 'utf8'));

// 步骤模块
const { navigate } = require('./steps/navigate');
const { fillUsername } = require('./steps/username');
const { fillPassword } = require('./steps/password');
const { extractBalance } = require('./steps/balance');
const { logout } = require('./steps/logout');

// 状态管理
const { checkCooldown, recordLogin, recordLogout } = require('./lib/state');

async function checkBalance(accountId, retryCount = 0) {
  const account = config.accounts.find(a => a.id === accountId);
  if (!account) throw new Error(`未知账户: ${accountId}`);

  const password = process.env[account.passwordEnv];
  if (!password) throw new Error(`未设置密码: ${account.passwordEnv}`);

  const result = {
    id: account.id, name: account.name, success: false,
    ves: null, usd: null, error: null, screenshot: null,
    timestamp: new Date().toISOString(),
  };

  // 检查冷却时间
  const cooldown = checkCooldown(accountId);
  if (cooldown.needWait) {
    console.log(`[${account.id}] ⏳ ${cooldown.reason}`);
    console.log(`  还需等待 ${cooldown.remainingSeconds} 秒...`);
    await new Promise(r => setTimeout(r, cooldown.remainingSeconds * 1000));
  }

  const { page, close: closeBrowser } = await launchBrowser();

  try {
    console.log(`[${account.id}] 开始查询余额...`);

    // 步骤 1：打开登录页
    const nav = await navigate(page, config);
    if (!nav.success) throw new Error(nav.error);

    // 步骤 2：填写用户名
    const user = await fillUsername(page, account.id, config);
    if (!user.success) throw new Error(user.error);

    // 步骤 3：填写密码并登录
    const pwd = await fillPassword(page, password, config);
    if (pwd.securityQuestions) {
      recordLogin(accountId);
      throw new Error('触发安全验证，请手动登录网站回答安全问题，重新配置信任设备');
    }
    if (!pwd.success) {
      if (!pwd.alreadyHome) recordLogin(accountId);
      throw new Error(pwd.error);
    }
    recordLogin(accountId);

    // 步骤 4：提取余额
    console.log(`[${account.id}] 登录成功，提取余额...`);
    const bal = await extractBalance(page, accountId);
    result.ves = bal.ves;
    result.usd = bal.usd;
    result.screenshot = bal.screenshot;
    result.success = true;

    console.log(`[${account.id}] ✅ 完成: VES=${result.ves || 'N/A'}, USD=${result.usd || 'N/A'}`);

    // 步骤 5：登出
    const logoutResult = await logout(page, config);
    if (logoutResult.success) {
      recordLogout(accountId);
    }

  } catch (error) {
    result.error = error.message;
    console.error(`[${account.id}] ❌ 失败:`, error.message);

    // 错误截图
    try {
      const errDir = path.join(__dirname, 'screenshots');
      await fs.promises.mkdir(errDir, { recursive: true });
      const errPath = path.join(errDir, `${account.id}-error-${Date.now()}.png`);
      await page.screenshot({ path: errPath, fullPage: true });
      result.screenshot = errPath;
    } catch (e) {}

    // 尝试登出
    const logoutResult = await logout(page, config).catch(() => ({ success: false }));
    if (logoutResult.success) {
      recordLogout(accountId);
    }

  } finally {
    await closeBrowser();
  }

  return result;
}

async function checkAll(accountIds = []) {
  const ids = accountIds.length > 0 ? accountIds : config.accounts.map(a => a.id);
  const results = [];

  for (const id of ids) {
    const result = await checkBalance(id);
    results.push(result);
    if (ids.indexOf(id) < ids.length - 1) {
      console.log('  等待 5 秒...\n');
      await new Promise(r => setTimeout(r, 5000));
    }
  }

  const output = { timestamp: new Date().toISOString(), results };
  const resultPath = path.join(__dirname, 'results', 'latest.json');
  await fs.promises.mkdir(path.dirname(resultPath), { recursive: true });
  await fs.promises.writeFile(resultPath, JSON.stringify(output, null, 2));

  return output;
}

if (require.main === module) {
  const args = process.argv.slice(2);
  checkAll(args).then(output => {
    console.log('\n========================================');
    console.log('查询完成');
    console.log('========================================');
    output.results.forEach(r => {
      if (r.success) {
        console.log(`✅ ${r.name}:`);
        console.log(`   VES: ${r.ves || 'N/A'}`);
        console.log(`   USD: ${r.usd || 'N/A'}`);
      } else {
        console.log(`❌ ${r.id}: ${r.error}`);
      }
    });
  }).catch(console.error);
}

module.exports = { checkBalance, checkAll };
