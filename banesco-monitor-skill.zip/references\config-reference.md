# config.json 配置详解

`scripts/config.json` 是整个工具的核心配置，包含三个部分：账户、选择器、URL。

## accounts — 账户列表

```json
{
  "accounts": [
    {
      "id": "myaccount",
      "name": "个人账户 - MY NAME",
      "type": "personal",
      "passwordEnv": "BANESCO_MYACCOUNT_PASS"
    },
    {
      "id": "company",
      "name": "公司账户 - COMPANY",
      "type": "business",
      "passwordEnv": "BANESCO_COMPANY_PASS"
    }
  ]
}
```

| 字段 | 类型 | 说明 |
|------|------|------|
| `id` | string | 账户唯一标识，用作命令行参数（如 `node check.js myaccount`）和用户名登录 |
| `name` | string | 显示名称，仅用于日志输出 |
| `type` | string | 账户类型标记（`personal` / `business`），目前仅用于标识 |
| `passwordEnv` | string | 存放密码的环境变量名，脚本运行时从 `process.env[passwordEnv]` 读取 |

### 添加新账户

1. 在 `accounts` 数组中新增一条记录
2. 设置对应的环境变量（PowerShell: `$env:BANESCO_XXX_PASS = "password"`）
3. 运行 `node setup.js <新账户id>` 完成信任设备配置

## selectors — CSS 选择器

这些是 Banesco Online 网页中各元素的 CSS 选择器。每个操作步骤都有主选择器和备用选择器（`*Alt`）。

```json
{
  "selectors": {
    "usernameInput": "input[name='txtUsuario']",
    "usernameInputAlt": "input#txtUsuario",
    "usernameSubmit": "input[name='btnAceptar']",
    "usernameSubmitAlt": "input[type='submit']",
    "passwordInput": "input[name='txtClave']",
    "passwordInputAlt": "input[type='password']",
    "trustDeviceCheckbox": "input[name='chkTrustDevice']",
    "passwordSubmit": "input[name='btnValidar']",
    "passwordSubmitAlt": "input[type='submit']",
    "vesBalance": "text=Cuenta Corriente",
    "usdBalance": "text=Cuenta Verde",
    "logoutLink": "a[href*='Logout']",
    "logoutLinkAlt": "a:has-text('Salir')"
  }
}
```

| 选择器 | 用途 | 使用位置 |
|--------|------|---------|
| `usernameInput` / `Alt` | 用户名输入框 | steps/username.js |
| `usernameSubmit` / `Alt` | 用户名提交按钮（Aceptar） | steps/username.js |
| `passwordInput` / `Alt` | 密码输入框 | steps/password.js, lib/detect.js |
| `trustDeviceCheckbox` | "信任此设备"复选框 | setup.js（手动勾选） |
| `passwordSubmit` / `Alt` | 密码提交按钮（Validar） | steps/password.js |
| `vesBalance` / `usdBalance` | 余额区域标识文本 | steps/balance.js, lib/detect.js |
| `logoutLink` / `Alt` | 登出链接 | steps/logout.js |

**注意：** 如果 Banesco 改版导致选择器失效，用 `node debug.js <accountId>` 调试，然后更新对应选择器。

## urls — 银行页面 URL

```json
{
  "urls": {
    "login": "https://www.banesconline.com/mantis/Website/Login.aspx",
    "logout": "https://www.banesconline.com/Mantis/WebSite/salir.aspx",
    "transferTerceros": "https://www.banesconline.com/Mantis/WebSite/transferencias/tercerosbanesco.aspx"
  }
}
```

| URL | 用途 |
|-----|------|
| `login` | 登录入口页 |
| `logout` | 强制登出页（直接 GET 即登出） |
| `transferTerceros` | 同行第三方转账页 |

这些是 Banesco Online 的官方 URL，正常情况下不需要修改。
