/**
 * 步骤5：登出
 * 优先通过直接导航到登出页面来强制登出，比查找链接元素更可靠。
 */

/**
 * 登出
 * @param {import('playwright').Page} page
 * @param {object} config - config.json 内容
 * @param {object} [options]
 * @param {function} [options.log] - 日志函数
 * @returns {Promise<{success: boolean}>}
 */
async function logout(page, config, options = {}) {
  const log = options.log || console.log;

  try {
    log('  正在登出...');

    // 直接导航到登出页面（最可靠的方式）
    if (config.urls.logout) {
      await page.goto(config.urls.logout, { waitUntil: 'domcontentloaded', timeout: 15000 });
      await page.waitForTimeout(2000);
      log('  ✅ 登出完成');
      return { success: true };
    }

    // 备选：查找登出链接并点击
    const { findInFrames } = require('../lib/frame-utils');
    const selectors = config.selectors;

    const logoutResult = await findInFrames(page, [
      selectors.logoutLink,
      selectors.logoutLinkAlt,
    ], { timeout: 5000 });

    if (logoutResult) {
      await logoutResult.element.click();
      await page.waitForTimeout(3000);
      log('  ✅ 登出完成');
      return { success: true };
    }

    log('  ⚠️ 未找到登出方式');
    return { success: false };
  } catch (error) {
    log(`  ⚠️ 登出失败: ${error.message}`);
    return { success: false };
  }
}

module.exports = { logout };
