/**
 * 步骤：单笔同行转账（Terceros en Banesco）
 * 完整流程：导航→选账户→目录搜索→填表→两次确认→回执截图
 * 仅支持目录内联系人（不需要特殊密码/OTP）。
 */

const fs = require('fs');
const path = require('path');
const { findInFrames, waitForAnyInFrames } = require('../lib/frame-utils');

/**
 * 在目录页面（主页面或弹窗）中查找搜索输入框。
 * @param {import('playwright').Page} surface
 * @param {number} timeout
 * @returns {Promise<{element: import('playwright').ElementHandle, frame: import('playwright').Frame}|null>}
 */
async function waitDirectorySearchInput(surface, timeout = 12000) {
  return waitForAnyInFrames(surface, [
    'input[type="search"]',
    'input[aria-controls]',
    'input[placeholder*="buscar" i]',
    'input[placeholder*="search" i]',
    'input[name*="buscar" i]',
    'input[name*="search" i]',
    'input[id*="buscar" i]',
    'input[id*="search" i]',
  ], timeout);
}

/**
 * 在所有 frame 中收集目录表格行。
 * @param {import('playwright').Page} surface
 * @param {import('playwright').Frame|null} [preferredFrame]
 * @returns {Promise<import('playwright').ElementHandle[]>}
 */
async function collectDirectoryRows(surface, preferredFrame = null) {
  const frames = surface.frames();
  const orderedFrames = preferredFrame
    ? [preferredFrame, ...frames.filter(f => f !== preferredFrame)]
    : frames;

  for (const frame of orderedFrames) {
    try {
      const rows = await frame.$$('table.dataTable tbody tr, table tbody tr');
      if (rows.length > 0) {
        return rows;
      }
    } catch (e) {}
  }
  return [];
}

/**
 * 判断目录行是否可见（过滤 DataTable 被隐藏的行）。
 * @param {import('playwright').ElementHandle} row
 * @returns {Promise<boolean>}
 */
async function isVisibleRow(row) {
  try {
    if (!(await row.isVisible())) {
      return false;
    }
    const box = await row.boundingBox();
    return !!box && box.width > 0 && box.height > 0;
  } catch (e) {
    return false;
  }
}

/**
 * 按内容键去重目录候选行（处理同一条数据被重复渲染的情况）。
 * @param {Array<{row: import('playwright').ElementHandle, aliasLink: import('playwright').ElementHandle, text: string, key: string}>} items
 * @returns {Array<{row: import('playwright').ElementHandle, aliasLink: import('playwright').ElementHandle, text: string, key: string}>}
 */
function dedupeRowCandidates(items) {
  const map = new Map();
  for (const item of items) {
    if (!map.has(item.key)) {
      map.set(item.key, item);
    }
  }
  return [...map.values()];
}

/**
 * 提取文本中的数字串（去掉空格/短横线等分隔符）。
 * @param {string} text
 * @param {number} [minLen=8]
 * @returns {string[]}
 */
function extractDigitTokens(text, minLen = 8) {
  const raw = (text || '').match(/\d[\d\s().-]{7,}/g) || [];
  const normalized = raw
    .map(s => s.replace(/\D/g, ''))
    .filter(s => s.length >= minLen);
  return [...new Set(normalized)];
}

/**
 * 校验确认弹窗里的账号是否与目标账号一致。
 * 仅在"出现了长账号且明确不匹配"时拦截，避免误杀掩码/格式化文本。
 * @param {string} popupText
 * @param {string} accountDigits
 * @returns {{ok: boolean, reason: string, candidates: string[]}}
 */
function validateConfirmationAccount(popupText, accountDigits) {
  const candidates = extractDigitTokens(popupText, 8);
  const tail10 = accountDigits.slice(-10);
  const tail8 = accountDigits.slice(-8);

  const hasExact = candidates.some(c => c === accountDigits);
  const hasTail10 = candidates.some(c => tail10 && (c.endsWith(tail10) || c.includes(tail10)));
  const hasTail8 = candidates.some(c => tail8 && c.endsWith(tail8));
  if (hasExact || hasTail10 || hasTail8) {
    return { ok: true, reason: 'matched', candidates };
  }

  if (candidates.length === 0) {
    return { ok: true, reason: 'no-numeric-token', candidates };
  }

  const longCandidates = candidates.filter(c => c.length >= 16);
  if (longCandidates.length > 0) {
    return { ok: false, reason: 'explicit-mismatch', candidates: longCandidates };
  }

  // 只出现短数字片段时，不作为强拦截条件
  return { ok: true, reason: 'weak-evidence', candidates };
}

/**
 * 文本标准化（小写 + 去重音符号），便于西语关键词匹配。
 * @param {string} text
 * @returns {string}
 */
function normalizeMatchText(text) {
  return (text || '')
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '');
}

/**
 * 判断是否为第一次确认弹窗文本。
 * @param {string} text
 * @returns {boolean}
 */
function isFirstConfirmationText(text) {
  const normalized = normalizeMatchText(text);
  if (normalized.includes('esta por realizar una transferencia a')) {
    return true;
  }
  if (normalized.includes('confirmacion') && normalized.includes('transferencia')) {
    return true;
  }
  return normalized.includes('transferencia') && normalized.includes('monto bs');
}

/**
 * 轮询等待第一次确认弹窗出现，返回命中的 frame 与文本。
 * @param {import('playwright').Page} page
 * @param {number} [timeout=12000]
 * @returns {Promise<{found: boolean, frame?: import('playwright').Frame, text: string}>}
 */
async function waitFirstConfirmation(page, timeout = 12000) {
  const deadline = Date.now() + timeout;
  let lastText = '';

  while (Date.now() < deadline) {
    for (const frame of page.frames()) {
      try {
        const text = await frame.evaluate(() => document.body?.innerText || '');
        if (text) {
          lastText = text;
        }
        if (isFirstConfirmationText(text)) {
          return { found: true, frame, text };
        }
      } catch (e) {}
    }
    await page.waitForTimeout(400);
  }

  return { found: false, text: lastText };
}

/**
 * 在指定 frame 内点击可见的 Aceptar 按钮。
 * @param {import('playwright').Frame} frame
 * @returns {Promise<boolean>}
 */
async function clickVisibleAceptarInFrame(frame) {
  for (const selector of [
    '.swal2-popup.swal2-show button.swal2-confirm',
    'button.swal2-confirm',
    'button:has-text("Aceptar")',
    'input[value="Aceptar"]',
  ]) {
    const buttons = await frame.$$(selector);
    for (let i = buttons.length - 1; i >= 0; i--) {
      const btn = buttons[i];
      const visible = await btn.isVisible().catch(() => false);
      if (!visible) continue;
      const disabled = await btn.getAttribute('disabled').catch(() => null);
      const ariaDisabled = await btn.getAttribute('aria-disabled').catch(() => null);
      if (disabled !== null || ariaDisabled === 'true') continue;
      try {
        await btn.click({ timeout: 2000 });
        return true;
      } catch (e) {
        // 可能被遮挡，尝试下一个候选按钮
      }
    }
  }
  return false;
}

/**
 * 点击第一次确认弹窗中的 Aceptar（优先命中的 frame）。
 * @param {import('playwright').Page} page
 * @param {import('playwright').Frame} preferredFrame
 * @returns {Promise<boolean>}
 */
async function clickFirstConfirmationAccept(page, preferredFrame) {
  if (preferredFrame) {
    const preferredClicked = await clickVisibleAceptarInFrame(preferredFrame);
    if (preferredClicked) {
      return true;
    }
  }

  // 兜底：遍历所有 frame
  for (const frame of page.frames()) {
    const clicked = await clickVisibleAceptarInFrame(frame);
    if (clicked) {
      return true;
    }
  }
  return false;
}

/**
 * 查找回执区域元素（优先精确 selector，支持 frame）。
 * @param {import('playwright').Page} page
 * @returns {Promise<import('playwright').ElementHandle|null>}
 */
async function findReceiptElement(page) {
  const selectors = [
    '.recibo',
    '#ctl00_cp_wz',
    '#ctl00_cp_wz_CRbo_tblRbo',
    'span#ctl00_cp_wz_CRbo_lblRboNroRecibo',
  ];

  for (const frame of page.frames()) {
    for (const selector of selectors) {
      try {
        const el = await frame.$(selector);
        if (!el) continue;

        const visible = await el.isVisible().catch(() => false);
        if (!visible) continue;

        // 若只命中回执号文本，回溯到 `.recibo` 容器优先截图
        if (selector === 'span#ctl00_cp_wz_CRbo_lblRboNroRecibo') {
          const container = await el.evaluateHandle(node => node.closest('.recibo') || node.closest('table') || node);
          const containerEl = container.asElement();
          if (containerEl) return containerEl;
        }

        return el;
      } catch (e) {}
    }
  }

  return null;
}

/**
 * 执行单笔转账
 * @param {import('playwright').Page} page - 已登录的页面
 * @param {object} config - config.json 内容
 * @param {object} transferConfig - 单笔转账配置
 * @param {string} transferConfig.account - 收款账号（20位）
 * @param {string} transferConfig.amount - 金额（如 "1500,00"）
 * @param {string} transferConfig.concept - 概念/备注（英文字符，>3字符）
 * @param {string} [transferConfig.name] - 收款人名称（仅用于日志）
 * @param {string} [sourceAccount="VES"] - 扣款账户类型 "VES" 或 "USD"
 * @param {object} [options]
 * @param {function} [options.log] - 日志函数
 * @returns {Promise<{success: boolean, receiptNumber?: string, screenshot?: string, error?: string}>}
 */
async function transfer(page, config, transferConfig, sourceAccount = 'VES', options = {}) {
  const log = options.log || console.log;
  const { account, amount, concept, name: recipientName } = transferConfig;
  const label = recipientName || account;

  try {
    // ========== 步骤 1：导航到转账页 ==========
    log(`  [${label}] 导航到转账页...`);
    await page.goto(config.urls.transferTerceros, {
      waitUntil: 'networkidle',
      timeout: 60000,
    });
    await page.waitForTimeout(2000);

    // ========== 步骤 2：选择扣款账户 ==========
    log(`  [${label}] 选择扣款账户 (${sourceAccount})...`);
    const accountDropdown = await page.$('select');
    if (!accountDropdown) {
      return { success: false, error: '找不到账户下拉框' };
    }

    // 获取所有 option 并按类型匹配
    const options_list = await accountDropdown.$$('option');
    let targetValue = null;
    for (const opt of options_list) {
      const text = await opt.textContent();
      const value = await opt.getAttribute('value');
      if (!value) continue;
      if (sourceAccount === 'VES' && text.includes('Cuenta Corriente')) {
        targetValue = value;
        break;
      }
      if (sourceAccount === 'USD' && text.includes('Cuenta Verde')) {
        targetValue = value;
        break;
      }
    }

    if (!targetValue) {
      return { success: false, error: `找不到 ${sourceAccount} 类型的账户` };
    }

    await accountDropdown.selectOption(targetValue);
    await page.waitForTimeout(2000);
    log(`  [${label}] ✅ 已选择扣款账户`);

    // ========== 步骤 3：点击 Directorio ==========
    log(`  [${label}] 打开联系人目录...`);
    const dirBtn = await findInFrames(page, [
      'input[value="Directorio"]',
      'button:has-text("Directorio")',
    ], { timeout: 8000 });
    if (!dirBtn) {
      return { success: false, error: '找不到 Directorio 按钮' };
    }

    // Directorio 可能在当前页弹窗，也可能打开新窗口；两种都处理
    const popupPromise = page.waitForEvent('popup', { timeout: 7000 }).catch(() => null);
    await dirBtn.element.click();
    const popupPage = await popupPromise;
    const directorySurface = popupPage || page;

    if (popupPage) {
      log(`  [${label}] 检测到目录新窗口，切换到弹窗处理...`);
      await popupPage.waitForLoadState('domcontentloaded', { timeout: 10000 }).catch(() => {});
    }
    await directorySurface.waitForTimeout(1500);

    // ========== 步骤 4：搜索收款账号（可选） ==========
    const searchBox = await waitDirectorySearchInput(directorySurface, 12000);
    const searchFrame = searchBox ? searchBox.frame : null;
    if (searchBox) {
      log(`  [${label}] 搜索账号: ${account}...`);
      await searchBox.element.click().catch(() => {});
      await searchBox.element.fill('');
      // 用真实键盘输入触发目录插件的 keyup/filter 逻辑，避免只改值不触发过滤
      await searchBox.element.type(account, { delay: 40 });
      await searchBox.element.press('Enter').catch(() => {});
      await directorySurface.waitForTimeout(2000);
    } else {
      log(`  [${label}] ⚠️ 未检测到搜索框，改为直接匹配目录表格...`);
    }

    // ========== 步骤 5：验证目录内 ==========
    // 检查目录表格中的结果行数
    let rows = await collectDirectoryRows(directorySurface, searchFrame);
    if (rows.length === 0) {
      await directorySurface.waitForTimeout(2500);
      rows = await collectDirectoryRows(directorySurface, searchFrame);
    }
    if (rows.length === 0) {
      return { success: false, error: '目录已打开，但未找到可解析的联系人表格' };
    }

    const accountDigits = account.replace(/\D/g, '');

    // 过滤掉"没有结果"的行
    const visibleRows = [];
    const matchedRows = [];
    for (const row of rows) {
      if (!(await isVisibleRow(row))) {
        continue;
      }

      const text = ((await row.textContent()) || '').trim();
      if (!text || text.includes('No matching') || text.includes('No se encontraron')) {
        continue;
      }

      // 只保留可点击联系人行，过滤表格辅助行/展开子行
      const aliasLink = await row.$('a');
      if (!aliasLink) {
        continue;
      }

      const aliasText = ((await aliasLink.textContent()) || '').trim().toLowerCase();
      const aliasHref = (await aliasLink.getAttribute('href')) || '';
      const key = `${text.replace(/\s+/g, ' ').toLowerCase()}|${aliasText}|${aliasHref}`;

      const candidate = { row, aliasLink, text, key };
      visibleRows.push(candidate);

      const rowHtml = await row.evaluate(el => el.outerHTML).catch(() => '');
      const rowDigits = `${text} ${rowHtml}`.replace(/\D/g, '');
      if (rowDigits.includes(accountDigits)) {
        matchedRows.push(candidate);
      }
    }

    const dedupVisibleRows = dedupeRowCandidates(visibleRows);
    const dedupMatchedRows = dedupeRowCandidates(matchedRows);

    log(`  [${label}] 目录候选: 匹配=${dedupMatchedRows.length}, 可见=${dedupVisibleRows.length}`);
    // 规则：
    // 1) 只要有完整账号匹配，允许继续；若匹配多条默认选第一条（同账号重复保存场景）
    // 2) 若没有完整匹配，仅在可见行唯一时放行；其余视为歧义
    let selectedRow = null;
    if (dedupMatchedRows.length > 0) {
      selectedRow = dedupMatchedRows[0];
      if (dedupMatchedRows.length > 1) {
        log(`  [${label}] ⚠️ 检测到同账号重复联系人 (${dedupMatchedRows.length})，默认使用第一条`);
      }
    } else if (dedupVisibleRows.length === 1) {
      selectedRow = dedupVisibleRows[0];
    }

    if (!selectedRow) {
      return { success: false, error: `账号 ${account} 不在目录内，拒绝转账` };
    }
    if (dedupMatchedRows.length === 0 && dedupVisibleRows.length > 1) {
      return { success: false, error: `账号 ${account} 可见多条非精确匹配记录 (${dedupVisibleRows.length})，需要人工确认` };
    }

    log(`  [${label}] ✅ 目录记录已选定`);

    // ========== 步骤 6：点击 alias 自动填充 ==========
    const aliasLink = selectedRow.aliasLink;
    if (!aliasLink) {
      return { success: false, error: '找不到 alias 链接' };
    }
    await aliasLink.click();
    if (popupPage && !popupPage.isClosed()) {
      // 有些银行页面点 alias 后会异步回填主页面，再关闭弹窗
      await popupPage.waitForTimeout(600).catch(() => {});
    }
    await page.waitForTimeout(2000);

    // 验证表单已填充 — 检查账号输入框的值
    const accountInput = await page.$('input[name*="txtCuenta"], input[name*="txtCuentaDestino"]');
    if (accountInput) {
      const filledValue = await accountInput.inputValue();
      if (!filledValue || filledValue.length < 10) {
        return { success: false, error: '表单未正确自动填充' };
      }
    }
    log(`  [${label}] ✅ 表单已自动填充`);

    // ========== 步骤 7：填写金额和概念 ==========
    log(`  [${label}] 填写金额: ${amount}, 概念: ${concept}...`);

    // 查找金额输入框（Monto）
    const montoInput = await page.$('input[name*="txtMonto"], input[name*="Monto"]');
    if (!montoInput) {
      return { success: false, error: '找不到金额输入框' };
    }
    await montoInput.fill(amount);

    // 查找概念输入框（Concepto）
    const conceptoInput = await page.$('input[name*="txtConcepto"], input[name*="Concepto"], textarea[name*="txtConcepto"]');
    if (!conceptoInput) {
      return { success: false, error: '找不到概念输入框' };
    }
    await conceptoInput.fill(concept);

    log(`  [${label}] ✅ 金额和概念已填写`);

    // ========== 步骤 8：第一次提交 ==========
    log(`  [${label}] 提交转账...`);
    const submitBtn = await page.$('input[value="Aceptar"]:not([style*="display: none"])') ||
                      await page.$('button:has-text("Aceptar")');
    if (!submitBtn) {
      return { success: false, error: '找不到 Aceptar 按钮' };
    }
    await submitBtn.click();
    await page.waitForTimeout(2000);

    // ========== 步骤 9：第一次确认弹窗 ==========
    log(`  [${label}] 等待第一次确认弹窗...`);

    const firstConfirm = await waitFirstConfirmation(page, 12000);
    if (!firstConfirm.found) {
      const sample = normalizeMatchText(firstConfirm.text).slice(0, 120) || 'N/A';
      return { success: false, error: `第一次确认弹窗未出现（文本片段: ${sample}）` };
    }

    // 安全校验：确认弹窗账号匹配（对格式化/掩码更鲁棒）
    const confirmAccountCheck = validateConfirmationAccount(firstConfirm.text, accountDigits);
    if (!confirmAccountCheck.ok) {
      const samples = confirmAccountCheck.candidates.slice(0, 3).join(', ') || 'N/A';
      return { success: false, error: `确认弹窗中的账号不匹配（候选: ${samples}）` };
    }
    if (confirmAccountCheck.reason !== 'matched') {
      const samples = confirmAccountCheck.candidates.slice(0, 3).join(', ') || 'N/A';
      log(`  [${label}] ⚠️ 确认页账号校验为弱信号 (${confirmAccountCheck.reason})，候选: ${samples}`);
    }

    // 点击第一次确认弹窗中的 Aceptar
    const firstConfirmClicked = await clickFirstConfirmationAccept(page, firstConfirm.frame);
    if (!firstConfirmClicked) {
      return { success: false, error: '找不到确认弹窗的 Aceptar 按钮' };
    }
    log(`  [${label}] ✅ 已确认第一次弹窗`);
    await page.waitForTimeout(1800);

    // ========== 步骤 10：等待结果/处理可能的二次确认 ==========
    log(`  [${label}] 等待结果页（必要时自动二次确认）...`);
    const postConfirmDeadline = Date.now() + 20000;
    let secondConfirmClicked = false;

    while (Date.now() < postConfirmDeadline) {
      await page.waitForTimeout(1200);

      const mergedText = [];
      for (const frame of page.frames()) {
        try {
          const frameText = await frame.evaluate(() => document.body?.innerText || '');
          if (frameText) mergedText.push(frameText);
        } catch (e) {}
      }

      const normalized = normalizeMatchText(mergedText.join('\n'));
      if (normalized.includes('operacion exitosa')) {
        break;
      }

      const needsSecondConfirm = normalized.includes('seguro de realizar esta operacion') ||
                                 normalized.includes('estas seguro de realizar esta operacion');
      if (needsSecondConfirm && !secondConfirmClicked) {
        const clickedSecond = await clickFirstConfirmationAccept(page, null);
        if (clickedSecond) {
          secondConfirmClicked = true;
          log(`  [${label}] ✅ 已确认第二次弹窗`);
        }
      }
    }

    // ========== 步骤 11-14：检测结果、截图、提取回执号 ==========
    log(`  [${label}] 检测转账结果...`);
    return await extractReceipt(page, account, log);

  } catch (error) {
    return { success: false, error: `转账异常: ${error.message}` };
  }
}

/**
 * 从回执页面提取信息并截图
 * @param {import('playwright').Page} page
 * @param {string} account
 * @param {function} log
 * @returns {Promise<{success: boolean, receiptNumber?: string, screenshot?: string, error?: string}>}
 */
async function extractReceipt(page, account, log) {
  const pageText = await page.evaluate(() => document.body.innerText);

  if (!pageText.toLowerCase().includes('operación exitosa')) {
    // 检查是否有错误信息
    if (pageText.toLowerCase().includes('error') || pageText.toLowerCase().includes('no podemos')) {
      return { success: false, error: '转账失败: 服务器返回错误' };
    }
    return { success: false, error: '未检测到 Operación Exitosa' };
  }

  log(`  [${account}] ✅ Operación Exitosa!`);

  // 提取回执号
  let receiptNumber = null;
  const receiptMatch = pageText.match(/N[°º]\s*DE\s*RECIBO[:\s]*(\d+)/i);
  if (receiptMatch) {
    receiptNumber = receiptMatch[1];
    log(`  [${account}] 回执号: ${receiptNumber}`);
  }

  // 截图回执区域
  let screenshotPath = null;
  try {
    const screenshotDir = path.join(__dirname, '..', 'screenshots');
    await fs.promises.mkdir(screenshotDir, { recursive: true });
    screenshotPath = path.join(screenshotDir, `transfer-${account.slice(-6)}-${Date.now()}.png`);

    // 优先精确截图回执区域（.recibo）
    await page.waitForTimeout(800);
    const receiptElement = await findReceiptElement(page);
    if (receiptElement) {
      await receiptElement.screenshot({ path: screenshotPath });
    } else {
      // 降级：截全页
      await page.screenshot({ path: screenshotPath, fullPage: true });
    }
    log(`  [${account}] 截图已保存: ${path.basename(screenshotPath)}`);
  } catch (e) {
    log(`  [${account}] ⚠️ 截图失败: ${e.message}`);
  }

  // 点击 Aceptar 完成（回到转账页面准备下一笔）
  try {
    const finishBtn = await page.$('input[value="Aceptar"]');
    if (finishBtn) {
      await finishBtn.click();
      await page.waitForTimeout(2000);
    }
  } catch (e) {
    // 无所谓，下一笔会重新导航
  }

  return {
    success: true,
    receiptNumber,
    screenshot: screenshotPath,
  };
}

module.exports = { transfer };
