/**
 * 步骤1：打开登录页
 * 导航到银行登录页面，等待 iframe 加载，检查服务器错误。
 */

const { checkServerError } = require('../lib/detect');

/**
 * 打开登录页面
 * @param {import('playwright').Page} page
 * @param {object} config - config.json 内容
 * @param {object} [options]
 * @param {function} [options.log] - 日志函数，默认 console.log
 * @returns {Promise<{success: boolean, error?: string}>}
 */
async function navigate(page, config, options = {}) {
  const log = options.log || console.log;

  try {
    log('  正在打开登录页...');
    await page.goto(config.urls.login, {
      waitUntil: 'networkidle',
      timeout: 60000,
    });

    // 轮询等待 iframe 加载（frames.length > 1），最多 5s
    const deadline = Date.now() + 5000;
    while (Date.now() < deadline && page.frames().length <= 1) {
      await page.waitForTimeout(500);
    }

    log(`  ✅ 页面加载完成（${page.frames().length} 个 frame）`);

    // 检查服务器错误
    const serverError = await checkServerError(page);
    if (serverError.hasError) {
      return { success: false, error: serverError.reason };
    }

    return { success: true };
  } catch (error) {
    return { success: false, error: `页面加载失败: ${error.message}` };
  }
}

module.exports = { navigate };
