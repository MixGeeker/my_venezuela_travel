# 转账完整指南

## 转账类型

当前仅支持 **Terceros en Banesco**（同行第三方转账），即转账到其他 Banesco 账户。收款人必须已存在于银行的"Directorio"（通讯录）中。

## 单笔转账

```bash
node transfer.js --from <accountId> -t <收款账号>:<金额>:<概念>
```

### 参数说明

| 参数 | 说明 | 示例 |
|------|------|------|
| `--from <accountId>` | 登录/扣款账户 ID（对应 config.json 中的 id） | `--from myaccount` |
| `-t <转账参数>` | 格式: `收款账号:金额:概念`，用冒号分隔 | `-t 01340000000000000000:1500,00:pago` |

### 金额格式

- 使用**逗号**作为小数分隔符（委内瑞拉/欧洲格式）
- 使用**点**作为千位分隔符（可选）
- 示例：`1,00`、`1500,00`、`10.500,00`

### 概念/备注

- 最少 3 个字符
- 建议使用简单文本，避免特殊字符
- 如果概念中包含冒号，会被正确处理（`parts.slice(2).join(':')`）

### 示例

```bash
# 单笔转账
node transfer.js --from myaccount -t 01340000000000000000:1,00:pago_test

# 多笔转账（同一次登录）
node transfer.js --from myaccount -t 0134...0907:1500,00:mercancia -t 0134...7746:2000,00:servicios
```

## 批量转账（JSON 文件）

```bash
node transfer.js --from <accountId> --batch transfers.json
```

### JSON 格式

```json
{
  "sourceAccount": "VES",
  "defaults": {
    "concept": "pago"
  },
  "transfers": [
    {
      "name": "RECIPIENT NAME",
      "account": "01340000000000000000",
      "amount": "1500,00",
      "concept": "pago mercancia"
    },
    {
      "name": "ANOTHER RECIPIENT",
      "account": "01340000000000000001",
      "amount": "2000,00"
    }
  ]
}
```

| 字段 | 说明 |
|------|------|
| `sourceAccount` | 目前固定为 `"VES"`（脚本内部忽略此值，始终使用 VES 账户） |
| `defaults.concept` | 默认概念，当转账条目未指定 concept 时使用 |
| `transfers[].name` | 收款人名称（仅日志显示，非必需） |
| `transfers[].account` | 收款账号（20 位，必须在 Directorio 内） |
| `transfers[].amount` | 金额（逗号小数格式） |
| `transfers[].concept` | 概念（可选，未指定时用 defaults.concept） |

参考模板: `scripts/transfers.example.json`

## 转账流程

transfer.js 的内部执行顺序：

1. **会话检测** — 先尝试复用已有登录会话，避免重复登录触发安全验证
2. **登录**（如需要）— navigate → username → password 标准流程
3. **逐笔转账**（Fail-fast）：
   - 导航到 Terceros 页面
   - 选择扣款账户（Cuenta Corriente）
   - 点击 Directorio 打开联系人目录
   - 搜索收款账号，验证是否在目录内
   - 点击 alias 自动填充表单
   - 填写金额和概念
   - 第一次 Aceptar → 确认弹窗（校验账号匹配）→ 第二次确认
   - 检测"Operación Exitosa" → 提取回执号 → 截图回执
4. **登出** — 始终执行，即使有错误
5. **保存结果** — 写入 `results/transfer-latest.json`

**Fail-fast 机制：** 任何一笔转账失败，立即停止所有后续转账，剩余转账标记为"已跳过"。

## 输出文件

### results/transfer-latest.json

```json
{
  "timestamp": "2025-01-01T12:00:00.000Z",
  "loginAccount": "myaccount",
  "sourceAccount": "VES",
  "totalCount": 2,
  "successCount": 2,
  "failedAt": null,
  "results": [
    {
      "account": "01340000000000000000",
      "amount": "1500,00",
      "concept": "pago mercancia",
      "name": "RECIPIENT NAME",
      "success": true,
      "receiptNumber": "12345678",
      "screenshot": "screenshots/transfer-040907-1234567890.png"
    }
  ]
}
```

### 回执截图

- 路径: `screenshots/transfer-<账号后6位>-<timestamp>.png`
- 优先截取 `.recibo` 区域（精确），失败时降级为全页截图

## 错误处理

| 错误 | 原因 | 解决方法 |
|------|------|---------|
| 触发安全验证 | 银行要求重新回答安全问题 | `node setup.js <accountId>` 重新配置信任设备 |
| 账号不在目录内 | 收款人未保存到 Directorio | 手动登录银行网站添加联系人 |
| 确认弹窗账号不匹配 | 安全校验失败，目录选错了人 | 检查账号是否正确 |
| 第一次确认弹窗未出现 | 页面加载问题或表单验证失败 | 检查金额格式和概念长度 |
| 未检测到 Operación Exitosa | 转账被银行拒绝或超时 | 手动登录检查转账状态 |
| 前序转账失败，已跳过 | Fail-fast 机制跳过的后续转账 | 修复失败的转账后重新执行批次 |
