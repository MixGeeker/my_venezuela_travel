/**
 * 步骤3：填密码 + 点登录
 * 等待密码输入框出现，填入密码，点击登录按钮。
 * 核心修复步骤：先找密码框，找不到时再检测页面状态。
 */

const { findInFrames, findInFramesOnce, waitForAnyInFrames } = require('../lib/frame-utils');
const { detectPageState, PageState, checkServerError } = require('../lib/detect');

/**
 * 多信号判断是否已经进入主页（用于慢速网络场景）。
 * @param {import('playwright').Page} page
 * @param {object} config
 * @returns {Promise<{isHome: boolean, securityQuestions?: boolean, serverError?: string, signals: string[]}>}
 */
async function evaluateHomeArrival(page, config) {
  const signals = [];
  const state = await detectPageState(page, config);

  if (state.state === PageState.SECURITY_QUESTIONS) {
    return { isHome: false, securityQuestions: true, signals };
  }
  if (state.state === PageState.SERVER_ERROR) {
    return { isHome: false, serverError: state.detail || '服务器错误', signals };
  }
  if (state.state === PageState.HOME) {
    signals.push('state:home');
  }

  const url = page.url().toLowerCase();
  if (url.includes('/mantis/website/') && !url.includes('/website/login.aspx')) {
    signals.push('url:post-login');
  }

  const selectors = config.selectors || {};
  const logoutMarker = await findInFramesOnce(page, [
    selectors.logoutLink,
    selectors.logoutLinkAlt,
  ].filter(Boolean));
  if (logoutMarker) {
    signals.push('logout-entry');
  }

  const balanceMarker = await findInFramesOnce(page, [
    selectors.vesBalance,
    selectors.usdBalance,
  ].filter(Boolean));
  if (balanceMarker) {
    signals.push('balance-widget');
  }

  const strongSignalHit = signals.includes('state:home');
  const weakSignalCount = signals.filter(s => s !== 'state:home').length;
  return {
    isHome: strongSignalHit || weakSignalCount >= 2,
    signals,
  };
}

/**
 * 填写密码并登录
 * @param {import('playwright').Page} page
 * @param {string} password - 密码
 * @param {object} config - config.json 内容
 * @param {object} [options]
 * @param {function} [options.log] - 日志函数
 * @param {number} [options.waitTimeout=15000] - 等待密码框出现的超时时间
 * @param {number} [options.homeWaitTimeout=30000] - 登录后等待主页确认的超时时间
 * @param {number} [options.homePollInterval=1500] - 登录后主页检测轮询间隔
 * @param {number} [options.homeStableRounds=2] - 主页信号连续命中次数
 * @returns {Promise<{success: boolean, alreadyHome?: boolean, securityQuestions?: boolean, error?: string}>}
 */
async function fillPassword(page, password, config, options = {}) {
  const log = options.log || console.log;
  const selectors = config.selectors;
  const waitTimeout = options.waitTimeout || 15000;
  const homeWaitTimeout = options.homeWaitTimeout || 30000;
  const homePollInterval = options.homePollInterval || 1500;
  const homeStableRounds = options.homeStableRounds || 2;

  try {
    // 1. 先短暂等待页面加载，然后检测页面状态
    //    不能直接等 input[type='password']，因为安全问题页面也有这种输入框
    log('  等待密码页面加载...');
    await page.waitForTimeout(3000);

    // 先检查是否触发了安全问题（优先于密码检测）
    const earlyState = await detectPageState(page, config);
    if (earlyState.state === PageState.SECURITY_QUESTIONS) {
      log(`  ⚠️ 检测到安全问题验证: ${earlyState.detail || ''}`);
      return { success: false, securityQuestions: true };
    }
    if (earlyState.state === PageState.HOME) {
      log('  ✅ 已在主页（信任设备自动登录）');
      return { success: true, alreadyHome: true };
    }

    // 只用精确的 name 选择器等待密码框
    const passwordResult = await waitForAnyInFrames(page, [
      selectors.passwordInput,
    ], Math.max(waitTimeout - 3000, 1000));

    // 2. 如果超时未找到密码框，检测当前页面状态
    if (!passwordResult) {
      log('  ⚠️ 未找到密码输入框，检测页面状态...');
      const state = await detectPageState(page, config);

      switch (state.state) {
        case PageState.HOME:
          log('  ✅ 已在主页（信任设备自动登录）');
          return { success: true, alreadyHome: true };

        case PageState.SECURITY_QUESTIONS:
          log(`  ⚠️ 检测到安全问题验证: ${state.detail || ''}`);
          return { success: false, securityQuestions: true };

        case PageState.SERVER_ERROR:
          return { success: false, error: state.detail || '服务器错误' };

        case PageState.LOGIN:
          return { success: false, error: '仍在登录页，Aceptar 可能未生效' };

        default:
          return { success: false, error: `未知页面状态: ${state.state}` };
      }
    }

    // 3. 找到密码框，填入密码
    await passwordResult.element.fill(password);
    log('  ✅ 已填入密码');

    // 4. 查找并点击登录按钮
    const loginBtnResult = await findInFrames(page, [
      selectors.passwordSubmit,
      selectors.passwordSubmitAlt,
    ], { timeout: 5000 });

    if (!loginBtnResult) {
      return { success: false, error: '找不到登录按钮' };
    }

    await loginBtnResult.element.click();
    log('  ✅ 已点击登录');

    // 5. 等待页面响应，检测是否进入主页
    //    多信号 + 连续命中判断，最多等待 30 秒（可配置）
    const deadline = Date.now() + homeWaitTimeout;
    let stableHits = 0;
    let rounds = 0;

    while (Date.now() < deadline) {
      await page.waitForTimeout(homePollInterval);
      rounds += 1;

      // 先检查服务器错误
      const serverError = await checkServerError(page);
      if (serverError.hasError) {
        return { success: false, error: serverError.reason };
      }

      // 多信号检测主页
      const homeCheck = await evaluateHomeArrival(page, config);
      if (homeCheck.securityQuestions) {
        log('  ⚠️ 登录后触发安全问题');
        return { success: false, securityQuestions: true };
      }
      if (homeCheck.serverError) {
        return { success: false, error: homeCheck.serverError };
      }

      if (homeCheck.isHome) {
        stableHits += 1;
        if (stableHits >= homeStableRounds) {
          log(`  ✅ 登录成功，已进入主页（信号: ${homeCheck.signals.join(', ') || 'N/A'}）`);
          return { success: true };
        }
      } else {
        stableHits = 0;
      }

      if (rounds % 3 === 0) {
        const remaining = Math.max(0, Math.ceil((deadline - Date.now()) / 1000));
        log(`  ⏳ 等待主页稳定加载... 剩余 ${remaining}s`);
      }
    }

    // 超时后最终检查
    const finalCheck = await evaluateHomeArrival(page, config);
    if (finalCheck.securityQuestions) {
      return { success: false, securityQuestions: true };
    }
    if (finalCheck.isHome) {
      log(`  ✅ 登录成功（超时边缘确认，信号: ${finalCheck.signals.join(', ') || 'N/A'}）`);
      return { success: true };
    }

    return { success: false, error: `登录后 ${Math.round(homeWaitTimeout / 1000)} 秒内未进入主页` };
  } catch (error) {
    return { success: false, error: `密码步骤失败: ${error.message}` };
  }
}

module.exports = { fillPassword };
