/**
 * 步骤2：填用户名 + 点 Aceptar
 * 在 iframe 中查找用户名输入框，填入账户 ID，点击 Aceptar 提交。
 */

const { findInFrames } = require('../lib/frame-utils');

/**
 * 填写用户名并提交
 * @param {import('playwright').Page} page
 * @param {string} accountId - 用户名
 * @param {object} config - config.json 内容
 * @param {object} [options]
 * @param {function} [options.log] - 日志函数
 * @returns {Promise<{success: boolean, error?: string}>}
 */
async function fillUsername(page, accountId, config, options = {}) {
  const log = options.log || console.log;
  const selectors = config.selectors;

  try {
    // 查找用户名输入框
    const usernameResult = await findInFrames(page, [
      selectors.usernameInput,
      selectors.usernameInputAlt,
    ], { timeout: 10000 });

    if (!usernameResult) {
      return { success: false, error: '找不到用户名输入框' };
    }

    await usernameResult.element.fill(accountId);
    log(`  ✅ 已填入用户名: ${accountId}`);

    // 查找并点击 Aceptar 按钮
    const submitResult = await findInFrames(page, [
      selectors.usernameSubmit,
      selectors.usernameSubmitAlt,
    ], { timeout: 5000 });

    if (!submitResult) {
      return { success: false, error: '找不到 Aceptar 按钮' };
    }

    await submitResult.element.click();
    log('  ✅ 已点击 Aceptar');

    return { success: true };
  } catch (error) {
    return { success: false, error: `用户名步骤失败: ${error.message}` };
  }
}

module.exports = { fillUsername };
