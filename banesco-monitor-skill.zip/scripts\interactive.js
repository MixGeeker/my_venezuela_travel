const fs = require('fs');
const path = require('path');
const readline = require('readline');
const { launchBrowser } = require('./lib/browser');

const config = JSON.parse(fs.readFileSync(path.join(__dirname, 'config.json'), 'utf8'));

// 步骤模块
const { navigate } = require('./steps/navigate');
const { fillUsername } = require('./steps/username');
const { fillPassword } = require('./steps/password');
const { extractBalance } = require('./steps/balance');
const { logout } = require('./steps/logout');

// 状态管理
const { recordLogin, recordLogout } = require('./lib/state');

// 页面状态检测
const { detectPageState, PageState } = require('./lib/detect');

/**
 * 询问用户
 */
function askQuestion(query) {
  const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout,
  });
  return new Promise(resolve => rl.question(query, ans => {
    rl.close();
    resolve(ans);
  }));
}

/**
 * 等待用户完成手动操作后进入主页
 * @param {import('playwright').Page} page
 * @param {string} prompt - 提示文本
 */
async function waitForUserToReachHome(page, prompt) {
  console.log(prompt);
  let userInput = '';
  while (userInput.toLowerCase() !== 'done') {
    userInput = await askQuestion('输入 "done" 继续（或 "exit" 退出）: ');
    if (userInput.toLowerCase() === 'exit') {
      throw new Error('用户退出');
    }
    const state = await detectPageState(page, config);
    if (state.state === PageState.HOME) {
      console.log('   ✅ 检测到已在主页');
      return;
    }
    console.log('   未检测到主页，请继续完成登录...');
  }
}

async function checkBalanceInteractive(accountId) {
  const account = config.accounts.find(a => a.id === accountId);
  if (!account) throw new Error(`未知账户: ${accountId}`);

  const password = process.env[account.passwordEnv];
  if (!password) throw new Error(`未设置密码: ${account.passwordEnv}`);

  console.log(`\n========================================`);
  console.log(`交互式登录: ${account.name}`);
  console.log(`========================================\n`);

  const { page, close: closeBrowser } = await launchBrowser({ slowMo: 50 });

  try {
    // 步骤 1：打开登录页
    console.log('1. 打开登录页...');
    const nav = await navigate(page, config);
    if (!nav.success) throw new Error(nav.error);

    // 步骤 2：填写用户名
    console.log('\n2. 填写用户名...');
    const user = await fillUsername(page, account.id, config);
    if (!user.success) throw new Error(user.error);

    // 步骤 3：填写密码并登录
    console.log('\n3. 等待密码页面...');
    const pwd = await fillPassword(page, password, config);

    if (pwd.securityQuestions) {
      // 安全问题 → 让用户手动操作
      console.log('\n⚠️  检测到安全问题验证！');
      console.log('请在浏览器窗口中：');
      console.log('  1. 回答所有安全问题');
      console.log('  2. 点击 "Aceptar" 提交答案');
      console.log('  3. 勾选 "信任此设备"（重要！）');
      console.log('  4. 进入主页后，回到终端输入 "done" 继续\n');

      await waitForUserToReachHome(page, '');
      recordLogin(accountId);

    } else if (pwd.alreadyHome) {
      // 信任设备自动登录
      recordLogin(accountId);

    } else if (!pwd.success) {
      // 登录失败，让用户手动尝试
      console.log(`\n⚠️  自动登录失败: ${pwd.error}`);
      console.log('你可以在浏览器窗口中手动完成登录');

      await waitForUserToReachHome(page, '完成登录后输入 "done" 继续');

      const state = await detectPageState(page, config);
      if (state.state !== PageState.HOME) {
        throw new Error('登录未完成');
      }
      recordLogin(accountId);

    } else {
      // 自动登录成功
      recordLogin(accountId);
    }

    // 步骤 4：提取余额
    console.log('\n4. 提取余额...');
    const bal = await extractBalance(page, accountId);

    // 步骤 5：登出
    console.log('\n5. 正在登出...');
    const logoutResult = await logout(page, config);
    if (logoutResult.success) {
      recordLogout(accountId);
    }

    console.log('\n========================================');
    console.log('✅ 查询成功');
    console.log(`   VES: ${bal.ves || 'N/A'}`);
    console.log(`   USD: ${bal.usd || 'N/A'}`);
    console.log('========================================\n');

  } catch (error) {
    console.error(`\n❌ 失败:`, error.message);

    if (error.message !== '用户退出') {
      console.log('\n⚠️  浏览器窗口保持打开');
      console.log('你可以手动完成操作，完成后按回车关闭浏览器...');
      await askQuestion('');
    }

    await logout(page, config).catch(() => {});
  } finally {
    await closeBrowser();
  }
}

// 运行
const args = process.argv.slice(2);
const accountId = args[0];
if (!accountId) {
  console.error('用法: node interactive.js <账户ID>');
  process.exit(1);
}

checkBalanceInteractive(accountId).catch(console.error);
